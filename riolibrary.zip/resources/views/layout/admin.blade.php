@extends('index')

@section('body')
<div class = "jumbotron">
    <h1 class = "display-1 text-center">Rio's Library</h1>
</div>

<div class = "container">
    @yield('page-content')
</div>

@endsection