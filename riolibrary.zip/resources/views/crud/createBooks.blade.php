@extends('layout.admin')
@section('page-content')

<table class = "table table-hover">
    <thead>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Library Section</th>
            <th colspan = "2">Action</th>
        </tr>
    </thead>

    <tbody>
        @foreach($books as $book)
        <tr>
            <td>{{ $book->title }}</td>
            <td>{{ $book->author }}</td>
            <td>{{ $book->genre }}</td>
            <td>{{ $book->librarysection }}</td>
            <td><a href = "{{ route('deleteBooks', ['book_id' => $book->id]) }}">Delete</a></td>
            <td><a href = "{{ route('updateBooks', ['book_id' => $book->id]) }}">Edit</a></td>
        </tr>
        @endforeach
    </tbody>
</table>

<br>

<form action = "{{ route('createBooks') }}" method = "POST"> 
    {{ csrf_field() }}
    <div class = "form-group">
        <label for = "text">Title</label>
        <input type = "text" class = "form-control" name = "title" required value = "{{ old('title') }}">
    </div>

    <div class = "form-group">
        <label for = "text">Author</label>
        <input type = "text" class = "form-control" name = "author" required value = "{{ old('author') }}">
    </div>

    <div class = "form-group">
        <label for = "text">Genre</label>
        <input type = "text" class = "form-control" name = "genre" required value = "{{ old('genre') }}">
    </div>

    <div class = "form-group">
        <label for = "text">Library Section</label>
        <input type = "text" class = "form-control" name = "librarysection" required value = "{{ old('librarysection') }}">
    </div>

    <br>

    <button class = "btn" type = "submit">Save</button>
    <input type = "hidden" value = "{{ Session::token() }}" name = "_token"></input> 
</form>

@endsection