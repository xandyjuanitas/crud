@extends('layout.admin')
@section('page-content')
<br>

<div class="row">
    <div class="col-md-6">
        <h5>Create Books</h5><br>
        <form action = "{{ route('createBooks') }}" method = "POST"> 
            {{ csrf_field() }}
            <div class = "form-group">
                <label for = "text">Title</label>
                <input type = "text" class = "form-control" id = "title" name = "title">
            </div>

            <div class = "form-group">
                <label for = "text">Author</label>
                <input type = "text" class = "form-control" id = "author"  name = "author">
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class = "form-group">
                        <label for = "text">Genre</label>
                        <select name = "genre" class="form-control" id = "genre">
                            <option value = "Horror">Horror</option>
                            <option value = "Romance">Romance</option>
                            <option value = "Thriller">Thriller</option>
                            <option value = "Mystery">Mystery</option>
                            <option value = "Adventure">Adventure</option>
                        </select> 
                    </div>
                </div>

                <div class="col-md-6">
                    <div class = "form-group">
                        <label for = "text">Library Section</label>
                        <select name = "librarysection" class = "form-control" id = "librarysection">
                            <option value = "Circulation">Circulation</option>
                            <option value = "Periodical">Periodical Section</option>
                            <option value = "General">General Reference</option>
                            <option value = "Children">Children's Section</option>
                            <option value = "Fiction">Fiction</option>
                        </select>    
                    </div>
                </div>
            </div>

            <br>

            <button class = "btn btn-dark" type = "submit">Save</button>
        </form> 
    </div>

    <div class="col-md-6">
        <h5>Filter Books by</h5><br>
        <table class="table table-borderless">
            <tbody>
                <tr id="filter_col1" data-column="2">
                    <td>Title</td>
                    <td align="center"><input type="text" class="column_filter form-control form-control-sm" id="col2_filter"></td>
                </tr>

                <tr id="filter_col2" data-column="3">
                    <td>Author</td>
                    <td align="center"><input type="text" class="column_filter form-control form-control-sm" id="col3_filter"></td>
                </tr>

                <tr id="filter_col3" data-column="4">
                    <td>Genre</td>
                    <td align="center"><input type="text" class="column_filter form-control form-control-sm" id="col4_filter"></td>
                </tr>

                <tr id="filter_col4" data-column="5">
                    <td>Library Section</td>
                    <td align="center"><input type="text" class="column_filter form-control form-control-sm" id="col5_filter"></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<br><br><br>

<table id="searchResults" class="table table-hover" >
    <thead class="thead-dark">
        <tr>
            <th class="no-sort">Actions</th>
            <th class="no-sort"></th>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Library Section</th>
        </tr>
    </thead>

    <tbody>
    @foreach($books as $book)
        <tr>
            <td><a href = "{{ route('editBooks', ['book_id' => $book->id]) }}">Edit</a></td>
            <td><a href = "{{ route('deleteBooks', ['book_id' => $book->id]) }}">Delete</a></td>
            <td>{{ $book->title }}</td>
            <td>{{ $book->author }}</td>
            <td>{{ $book->genre }}</td>
            <td>{{ $book->librarysection }}</td>
        </tr>
    @endforeach
    </tbody>
</table>
<br>            

@endsection