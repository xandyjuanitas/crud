@extends('layout.admin')
@section('page-content')
<h4>Update Books</h4><br>
<form action = "{{ route('updateBooks', ['book_id' => $books->id]) }}" method = "POST"> 
    {{ csrf_field() }}
    <div class = "form-group">
        <label for = "text">Title</label>
        <input type = "text" class = "form-control" required value = "{{  $books->title }}" name = "title">
    </div>

    <div class = "form-group">
        <label for = "text">Author</label>
        <input type = "text" class = "form-control" required value = "{{  $books->author }}"  name = "author">
    </div>

    <div class = "form-group">
        <label for = "text">Genre</label>
        <select name = "genre" class="form-control" id = "genre" required value = "{{  $books->genre }}">
            <option value = "Horror">Horror</option>
            <option value = "Romance">Romance</option>
            <option value = "Thriller">Thriller</option>
            <option value = "Mystery">Mystery</option>
            <option value = "Adventure">Adventure</option>
        </select> 
    </div>

    <div class = "form-group">
        <label for = "text">Library Section</label>
        <select name = "librarysection" class="form-control" id = "librarysection" required value = "{{  $books->librarysection }}" >
            <option value = "Circulation">Circulation</option>
            <option value = "Periodical">Periodical Section</option>
            <option value = "General">General Reference</option>
            <option value = "Children">Children's Section</option>
            <option value = "Fiction">Fiction</option>
        </select> 
    </div>

    <br>

    <button class = "btn" type = "submit">Update</button>
    <input type = "hidden" value = "{{ Session::token() }}" name = "_token"></input> 
</form>
@endsection