<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Books; // we are invoking these class Books that we created before

class BooksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $books = Books::orderBy('created_at', 'desc')->get(); // get all those books
        return view('crud.home')->with('books', $books); // to view all those books
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if($request->input('title') != null && $request->input('author') != null && $request->input('genre') != null && $request->input('librarysection')) 
        {
            books::insert(['title' => $request->input('title'), 'author' => $request->input('author'), 'genre' => $request->input('genre'), 'librarysection' => $request->input('librarysection')]);

            return redirect()->back();
        }

        return redirect()->back();
    }

    public function edit($id)
    {
        $books = books::find($id);
        return view('crud.updateBooks')->with('books', $books);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        books::where('id', $id)->update([
            'title' => $request->input('title'),
            'author' => $request->input('author'),
            'genre' => $request->input('genre'),
            'librarysection' => $request->input('librarysection') 
        ]);
        return redirect('/');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $books = Books::where('id', $id)->first();
        $books->delete();
        return redirect()->back(); // going to give us the same page
    }

    public function search(Request $request)
    {
        $string = $request->get('string');
        $searchBy = $request->get('filter');

        if($searchBy == 'title')
        {

            $books = $books->where('city', 'like', '%'.$string.'%');
        }

        $books = Books::orderBy('created_at', 'desc')->get(); // get all those books
        return view('crud.home')->with('books', $books); // to view all those books
    }
}
