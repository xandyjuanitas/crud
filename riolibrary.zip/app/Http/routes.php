<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'BooksController@index');

Route::post('/createBooks', [
	'uses' => 'BooksController@create', 
	'as' => 'createBooks',
]);

Route::get('/searchBooks', [
	'uses' => 'BooksController@search', 
	'as' => 'searchBooks',
]);

Route::get('/deleteBooks/{book_id}', [
	'uses' => 'BooksController@delete',
	'as' => 'deleteBooks',
]);

Route::post('/updateBooks/{book_id}', [
	'uses' => 'BooksController@update',
	'as' => 'updateBooks',
]);

Route::get('/editBooks/{book_id}', [
	'uses' => 'BooksController@edit',
	'as' => 'editBooks',
]);

Route::get('/storeBooks/{book_id}', [
	'uses' => 'BooksController@store',
	'as' => 'storeBooks',
]);